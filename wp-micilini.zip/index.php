<?php
  //Não usamos mais o index.php por se tratar de um fallback file, se lembra?
?>