# Um Simples Tema para WordPress (WP-Micilini)

Este é um tema simples feito WordPress, criado com carinho pelo Portal da [Micilini](https://micilini.com) 🤖

Ele faz parte da [Jornada de Criação de Temas do WordPress](https://micilini.com/conteudos/wordpress) presente em nosso portal, vale a pena dar uma olhada 👀

# Como Instalar?

Para instalar este tema, basta criar uma pasta chamada ```wp-micilini``` dentro da pasta ```wp-content > themes``` da sua instância do WordPress.

