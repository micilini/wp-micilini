<?php get_header() ?>

<div class="d-flex align-items-center justify-content-center vh-100 bg-primary">
        <h1 class="display-1 fw-bold text-white">404</h1>
</div>

<?php get_footer() ?>